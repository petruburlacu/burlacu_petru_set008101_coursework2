import { Component } from '@angular/core';

@Component({
  selector: 'app-root', //tells html where to put component
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Nanomechanic';
}
